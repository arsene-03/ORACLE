package com.green.q1;


public class Controller {
	public Controller() {
		init();
	}

	private void init() {
		
		
		int num = (int)(Math.random()*45)+1;
		
		
		System.out.println("개수:"+num);
		
	}
}
