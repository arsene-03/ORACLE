import java.awt.PageAttributes.OriginType;

public class Q01 {

	public static void main(String[] args) {
		// 1. 가로가 3이고 세로가 6인 사각형의 넓이
		int width = 3;
		int height = 6;

		int lecArea = width * height;

		System.out.println("1. 사각형의 넓이: "+lecArea);
		System.out.println("--------------------");

		// 2. 위의 길이의 삼각형의 넓이
		double triArea = lecArea /2.0;

		System.out.println("2. 삼각형의 넓이: "+triArea);
		System.out.println("--------------------");

		//3. 성적이 40, 30, 10 나왔다 평균은

		int firScore = 40;
		int secScroe = 30;
		int thrScore = 10;

		int sumScore = firScore + secScroe + thrScore;
		double avgScore = sumScore / 3.0;

		System.out.println("3. 평균점수: "+avgScore);
		System.out.println("--------------------");

		//4. 월급이 100원이다 연봉은? (세금 20프로)

		int salary = 100;
		int preTaxSalary = salary*12;
		double afterTaxSalary = preTaxSalary*0.8;

		System.out.println("4. 연봉: "+afterTaxSalary);
		System.out.println("--------------------");

		//5. 286 초를 분초로 출력

		int time = 286;
		int minute = time /60;
		int second = time %60;

		System.out.printf("5. %d초는 %d분 %d초 입니다.\n",time,minute,second);
		System.out.println("--------------------");

		//6. 

		int x = 10;
		int y = 5;
		System.out.println("6. ");
		System.out.println((x>7) && (y<=5));
		System.out.println((x%3==0) || (y%2 !=1));
		System.out.println("--------------------");

		// 7. 176840원을 화폐매수대로 출력

		int money = 176840;
		int originmoney = money;
		int unit = 50000;

		int ohMan = money/unit;
		money %=unit; //5만원권 제외한 금액 : 26840
		unit /= 5; // 만원권으로 설정

		int man = money/unit;
		money %=unit; // 만원권을 제외한 금핵 6840
		unit /= 2; // 5천원권으로 설정

		int ohCheon = money/unit;
		money %=unit; //5만원권 제외한 금액 : 26840
		unit /= 5; // 만원권으로 설정

		int cheon = money/unit;
		money %=unit; 
		unit /= 2; // 5백원권으로 설정

		int ohBeak = money/unit;
		money %=unit; 
		unit /= 5; // 백원권으로 설정

		int beak = money/unit;
		money %=unit; 
		unit /= 2; // 50원권으로 설정

		int ohSip = money/unit;
		money %=unit; 
		unit /= 5; // 십원으로 설정

		int sip = money/unit;

		System.out.println("7. 금액: "+originmoney+"원");
		System.out.println(" 오만원권 : "+ ohMan+"개");
		System.out.println(" 만원권 : "+ man+"개");
		System.out.println(" 오천원권 : "+ ohCheon+"개");
		System.out.println(" 천원권 : "+ cheon+"개");
		System.out.println(" 오백원권 : "+ ohBeak+"개");
		System.out.println(" 백원권 : "+ beak+"개");
		System.out.println(" 오십원권 : "+ ohSip+"개");
		System.out.println(" 십원권 : "+ sip+"개");
		System.out.println("--------------------");

		//8. 점수에 따른 등급을 출력해보자.
		//		Int num = 70;
		//		90이상 A
		//		80이상 B
		//		70이상 C
		//		60이상 D
		//		59이하 F
		
		int num =70;
		
		char grad = (num>=90) ? 'A' : ((num>=80) ? 'B' : ((num>=70) ? 'C' : ((num>=60) ? 'D' : 'F')));
		System.out.println("8. 등급은: "+grad+" 입니다.");

	




	}

}
