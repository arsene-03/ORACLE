import java.util.Scanner;

public class Condition02 {

	public static void main(String[] args) {
		// 점수가 90점 이상이면 A등급을 출력
		// (A등급이 아니라면) 점수가 80점 이상이면 B등급을 출력
		// (A,B등급이 아니라면) 점수가 70점 이상이면 C등급을 출력
		// (A,B,C등급이 아니라면) 점수가 60점 이상이면 D등급을 출력
		// (A,B,C,D등급이 아니라면) 점수가 60점 미만이면 F등급을 출력
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요> ");
		int score = scan.nextInt();
		scan.nextLine();
		
		String grade="";
		
		if(score>=90) {
			grade = "A등급";
		}else if(score>=80) {
			grade = "B등급";
		}else if(score>=70) {
			grade = "C등급";
		}else if(score>=60) {
			grade = "D등급";
		}else {
			grade = "F등급";
		}
		
		System.out.println("당신의 등급은 "+grade+"입니다.");
		
		System.out.println("---------------------------------");
		System.out.println("오늘 선택할 점심 메뉴");
		System.out.println("1. 짜장면");
		System.out.println("2. 짬뽕면");
		System.out.println("3. 울면");
		System.out.println("4. 우동");
		System.out.println("5. 기스면");
		System.out.print("> ");
		
		String selecNum = scan.nextLine();
		
		switch(selecNum) {
		case "1":
			System.out.println("짜장면 하나 추가요");
			break;
		case "2":
			System.out.println("짬뽕면 하나 추가요");
			break;
		case "3":
			System.out.println("울면 하나 추가요");
			break;
		case "4":
			System.out.println("우동 하나 추가요");
			break;
		case "5":
			System.out.println("기스면 하나 추가요");
			break;
		default:
			System.out.println("그런 메뉴 없습니다.");
		}
		
		
		System.out.println("프로그램을 종료합니다.");
		

	}

}
