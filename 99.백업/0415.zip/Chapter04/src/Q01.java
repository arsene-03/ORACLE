
public class Q01 {

	public static void main(String[] args) {
		//1. 1부터 100까지의 합을 구하세요.
		int i = 0;
		int sum=0;
		for(i=1;i<=100;i++) {
			sum+=i;
		}
		System.out.println("1. "+sum);
		
		System.out.println("---------------------");
		
		//2. 1부터 100까지 7의 배수의 합을 구하세요.
		sum=0;
		for(i=1;i<=100;i++) {
			if(i%7==0) {
				sum+=i;
			}
		}
		System.out.println("2. "+sum);
		
		System.out.println("---------------------");
		
		//3. 1부터 100까지 7의 배수의 합과 평균을 구하세요
		int count = 0;
		sum=0;
		for(i=1;i<=100;i++) {
			if(i%7==0) {
				sum+=i;
				count++;
			}
		}
		double avg = sum/(double)count;
		System.out.println("3. 합: "+sum);
		System.out.println("    개수: "+count);
		System.out.println("    평균: "+avg);
		
		System.out.println("---------------------");
		
		//4. 1부터 100까지의 합을 구하되 합계 100이 넘어서면 연산을 중단하고 그때의 합계를 출력
		sum=0;
		count=0;
		int temp = 0;
		for(i=1;i<=100;i++) {
			sum+=i;
			if(sum>=1000) {
				temp=i;
				break;
			}
			
		}
		System.out.println("4. 순간의 항: "+temp);
		System.out.println("      합계: "+sum);
		
		System.out.println("---------------------");
		
	}

}
