import java.util.Scanner;

public class Q02_bank {

	public static void main(String[] args) {
		// 은행 문제
				int balance= 0; //잔액
				Scanner scan = new Scanner(System.in);
				boolean run = true;
				
				while(run) {
					System.out.println("그린 뱅크에 오신것을 환영합니다.");
					System.out.println("메뉴를 선택해 주세요.");
					System.out.println("1. 예금");
					System.out.println("2. 출금");
					System.out.println("3. 잔액조회");
					System.out.println("4. 종료");
					System.out.print("> ");
					
					int selectNum = Integer.parseInt(scan.nextLine());
					
					switch(selectNum) {
					case 1: // 예금 기능
						System.out.print("예금할 금액을 입력하세요.> ");
						int money = Integer.parseInt(scan.nextLine());
						balance += money; // 입금한 금액 만큼 잔액 증가
						System.out.println();
						System.out.println(money+ "원 입금했습니다.");
						System.out.println("*****************");
						//작성
						break;
					case 2: // 출금 기능
						System.out.print("출금할 금액을 입력하세요.> ");
						int withdraw = Integer.parseInt(scan.nextLine());
						if(balance < withdraw) {
							System.out.println("잔액부족");
						}else {
							balance -= withdraw;
							System.out.println(withdraw+ "원 출금했습니다.");
							System.out.println("*****************");
						}
						
						//작성
						break;
					case 3: // 잔액 조회 기능
						//작성
						System.out.println("예금된 잔액은"+balance+"원 입니다.");
						System.out.println("*****************");
						break;
					case 4: //프로그램 종료
						//작성
						System.out.println("프로그램을 종료합니다.");
	//					System.exit(0);
						run = false; // while 조건을 false 로 만들어서 반복종료
//						return; 함수를 끝내라라는 명령어
						break;
					default:
						//작성
						System.out.println("잘못 입력했습니다.");
						System.out.println();
					}
				}

	}

}
