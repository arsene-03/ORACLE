import java.util.Scanner;

public class Input03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int jumsu = scan.nextInt();//숫자입력
		// 98 enter(키코드 2개)
		scan.nextLine();// 키코드 찌꺼기를 제거하는 첫번째 방법

		String str = scan.nextLine();

		// 문자열로 입력받아서 숫자로 변환
		String str1 = scan.nextLine();  //      "98"  => 98
		int str2 = Integer.parseInt(str1);
		//숫자로 생긴 문자열을 정수로 변환해주는 코드       "구십육" => X
		//	   Integer.parseInt(문자열);
		//숫자로 생긴 문자열을 실수로 변환해주는 코드
		//	   Double.parseDouble(문자열); 


		int num = Integer.parseInt(scan.nextLine());   
		//키코드 찌꺼기를 제거하는 두번째 방법 

	}

}
