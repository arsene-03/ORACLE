import java.util.Scanner;

public class Condition01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("당신의 점수를 입력하세요 > ");
		int score = scan.nextInt();
		
		if(score>=60) {
			System.out.println("합격입니다.");
		}else {
			System.out.println("불합격입니다.");
		}
		
		System.out.println("프로그램을 종료합니다.");

	}

}
