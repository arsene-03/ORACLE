import java.util.Scanner;

public class Login {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		//미리 저장된 Id,password
		String id = "green";
		String password = "123456";

		System.out.println("로그인 프로그램");
		System.out.print("아이디 : ");
		String userId = scan.nextLine();
		System.out.print("비밀번호 : ");
		String userPassword = scan.nextLine();

		//				System.out.println("입력한 아이디 : "+userId);
		//				System.out.println("입력한 비밀번호 : "+userPassword);

		// 로그인 처리 프로그램을 만들어 봅시다.
		// 아이디가 틀린 경우 "아이디가 존재하지 않습니다."
		// 비밀번호가 틀린 경우 "잘못된 비밀번호입니다."
		// 아이디,비밀번호가 일치하는 경우 "로그인 성공"


		/*
		 * 입력된 아이디하고 저장된 아이디하고 일치한다면{
		 * 	   입력된 비밀번호하고 저장된 비밀번호하고 일치한다면{
		 * 			=>  로그인 성공
		 *    }입력된 비밀번호하고 저장된 비밀번호하고 일치하지 않는다면{
		 * 			=>  잘못된 비밀번호
		 *    }
		 * }입력된 아이디하고 저장된 아이디하고 일치하지 않는다면{
		 *    => 아이디가 존재하지 않습니다.
		 * }
		 */

		if(id.equals(userId)){
			if(userPassword.equals(password)) {
				System.out.println("로그인 성공");
			}else {
				System.out.println("잘못된 비밀번호");
			}
		}else {
			System.out.println("아이디가 존재하지 않습니다.");
		}

		if((id.equals(userId)) && (userPassword.equals(password))) {
			System.out.println("로그인 성공");
		}else {
			System.out.println("로그인 실패");
		}

	}

}
