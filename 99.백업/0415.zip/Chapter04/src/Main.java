import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		TreeSet<Integer> lotto = new TreeSet<>();
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("게임 횟수를 입력해주세요.");
		int gameCount = Integer.parseInt(scan.nextLine());


for(int j=0;j<gameCount;j++) {

		while(lotto.size()!=6) {
			int random = (int)(Math.random()*45)+1;
			lotto.add(random);
		}
		System.out.print("{");
		Iterator<Integer> itr = lotto.iterator(); // 반복자 호출 => 1회용

		while(itr.hasNext()) {//다음에 꺼낼 데이터가 있는가?
			Integer number = itr.next(); // 다음 데이터를 꺼내는 메서드
			System.out.print(number+" ");
			
		}
		System.out.print("}");
		System.out.println();
		lotto.clear();
		continue;
}





	}

}
