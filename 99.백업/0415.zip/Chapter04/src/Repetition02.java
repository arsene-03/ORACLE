
public class Repetition02 {

	public static void main(String[] args) {
		// for 반복문을 이용해서 10을 10번 출력
		for(int i=1;i<=10;i++) {
			System.out.println(10);
		}
		System.out.println("---------------------");
		
		// for 반복문을 이용하여 1부터 10까지 출력
		for(int i=1;i<=10;i++) {
			System.out.println(i);
		}
		System.out.println("---------------------");
		
		//for 반복문을 이용하여 1부터 10까지 합계출력
		int sum = 0;
		for(int i=1;i<=10;i++) {
			sum+=i;
		}
		System.out.println("합계는: "+sum);
	}

}
