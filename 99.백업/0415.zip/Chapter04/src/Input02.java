import java.util.Scanner;

public class Input02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		String str1 = scan.next();  // 공백이 입력되기 전까지 "문자열"를 입력받는 기능
		// 안녕 하세요  => 안녕
		System.out.println(str1);
		scan.nextLine();// next()로 인한 데이터 입력 오류 방지

		String str2 = scan.nextLine();   // 엔터가 입력되기 전까지 "문자열"를 입력받는 기능
		// 안녕 하세요  => 안녕 하세요
		System.out.println(str2);

		scan.nextInt();
		scan.nextDouble();

	}

}
