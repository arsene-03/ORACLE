
public class Q01 {

	public static void main(String[] args) {
		// 1. 다음과 같은 배열이 있을때 arr[3].lenghth의 값은 얼마인가.
		
		int[][] arr= {
				{5,5,5,5,5},
				{10,10,10},
				{20,20,20,20},
				{30,30}
		};
		System.out.println("1. "+arr[3].length);
		System.out.println("-----------------");
		
		// 2. 배열에 담긴 값들의 합계를 구하는 프로그램을 작성하세요
		
		int[]arr2 = new int[] {10,15,47,23,51};
		int sum=0;
		for(int i=0;i<arr2.length;i++) {
			sum += arr2[i];
		}
		System.out.println("2. "+sum);
		System.out.println("-----------------");
		
		// 3. 다음 2차원 배열에 담긴 모든 값들의 총합과 평균을 구하는 프로그램을 완성하세요.
		
		int[][]arr3 = {
				{5,5,5,5},
				{10,10,10,10,10},
				{20,20,20,20,20},
				{30,30,30,30,30},
		};
		sum=0;
		double avg = 0;
		int count = 0;
		for(int i=0;i<arr3.length;i++) {
			for(int j=0;j<arr3[i].length;j++) {
				sum += arr3[i][j];
				count++;
			}
		}
		
		avg = sum / (double)count;
		System.out.println("3. 총합: "+sum);
		System.out.println("     평균: "+avg);
		System.out.println("-----------------");
		
		//4. 1과9사이의 숫자로 이루어진 3자리 숫자를 만들어 내는 프로그램을 완성하세요 단 숫자의 중복이 있어서는 안됩니다.
		
		
//		int[] num = new int[3];
//		
//		for(int i=0;i<num.length;i++) {
//			if(num[i]==num[i+1]) {
//				num[i] = (int)(Math.random()*9)+1;	
//			}else {
//				System.out.print(num[i]);
//			}
//			
//			
//		}
//		System.out.println("-----------------");
		
		//5. 최대값과 해당 인덱스를 구해서 출력해 봅시다
		
		int []arr4 = new int[] {78,54,89,57,84,95,74,91,84,67,52,94,82};
		int max = arr4[0];
		int min = arr4[0];
		count = 0;
		for(int i=0;i<arr4.length;i++) {
			if(max<arr4[i]) {
				max = arr4[i];
				
			}
			if(min>arr4[i]) {
				min = arr4[i];
			}
		}
		System.out.println("가장 큰 수는"+max);
		System.out.println("가장 작은수는"+min);
		
		
		
		
		
		
	}

}
