
public class ConsoleOutput01 {

	public static void main(String[] args) {
		//콘솔출력입니다.
		System.out.println("안녕하세요");
		System.out.println(20);
		System.out.println(20+7);
		System.out.println("안녕"+"하세요");
		System.out.println("20"+7);
		System.out.println();
		
		System.out.print("안녕하세요");
		System.out.print("안녕"+"하세요");
		System.out.println();
		
		System.out.printf("제 이름은 %s입니다. \n","홍길동");
		System.out.printf("제 자바점수는 %d점 입니다. \n",90);

		
	}

}
