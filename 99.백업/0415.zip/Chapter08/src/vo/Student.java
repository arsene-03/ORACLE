package vo;

class Student { // 디폴트 클래스

}
