package vo;

public class Lecturer {

}
