package main;

//import dto.Teacher;
//import dto.Student;
//import dto.*; // dot 안에 클래스를 모두 사용함 (권장하진 않음)
import vo.Lecturer;



public class Main {

	public static void main(String[] args) {
		Student studentDto = new Student();
//		Teacher teacherDto = new Teacher();
		
//		vo.Student studentVo = new vo.Student();
		Lecturer lecturervo = new Lecturer();
		
		Student student = new Student();
		
		java.util.Scanner scan = new java.util.Scanner(System.in);
		
		/*java.lang.*/System.out.println();
		/*java.lang.*/Math.random();

	}

}
