package main;

class Student {

}
