package dto;

public class Student {

}
