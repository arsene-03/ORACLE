package dto;

public class Teacher {

}
