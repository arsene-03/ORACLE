
public class Variable02 {

	public static void main(String[] args) {
		// 정수형 자료형
		byte a;
		short b;
		int c;
		long d;

		a = -128;
		a = 127;
		//				a = 128;
		//				
		//				b = 40000;
		//				
		//				c = 2200000000;
		d = 2200000000L;

		// 실수형 자료형
		float e;
		double f; //***

		e = 3.14f;
		f = 3.14;

		f = 3.14e+14;

		// 리터럴

		// 문자

		char g = 52240;
		char h = '찐';

		System.out.println("g에 들어간 문자 : "+g);
		System.out.println("h에 들어간 문자 : "+h);

		//논리 자료형
		boolean i = true;
		boolean j = false;

		System.out.println("i의 데이터 :"+i);
		int engScore;
		int mathScore;
		engScore = 55;
		mathScore = 75;

		boolean k = engScore > mathScore;
		System.out.println("수학점수보다 영어점수가 더 큰가?"+k);

	}

}
