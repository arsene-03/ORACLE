
public class Variable01 {

	public static void main(String[] args) {
		int korScore;

		korScore = 80;

		System.out.printf("제 국어점수는 %d 입니다. \n",korScore);
		System.out.println();
		System.out.println("제 국어점수는 "+korScore+"점입니다.");

		int engScore;
		int mathScore;

		korScore = 65;
		engScore = 55;
		mathScore = 75;

		int sumScore = korScore + engScore + mathScore;

		// 변수 안에 데이터를 삭제하는 방법  : 가비지 컬렉터[JVM]

		int korScore3;
		//int 3korScore; => 이름첫글자는 숫자 안됨
		//int class; => 특정 단어 사용 불가

		int java702HongJavaScore;
		// 단어구분
		// 1. 낙타체 (camelCase)
		//	java702HongJavaScore
		// 2. 뱀체 (snackCase)
		//	java_702_hong_java_score
		// 3. 파스칼 케이스
		// Java702HongJavaScore

	}

}
