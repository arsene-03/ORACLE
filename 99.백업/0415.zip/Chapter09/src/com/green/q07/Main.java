package com.green.q07;

import java.util.Scanner;

public class Main {
	static Scanner scan = new Scanner(System.in);
	static Member[] member = new Member[100];
	public static int session = -1;
	
	public static void main(String[] args) {
		new Controller();
		
	}
}