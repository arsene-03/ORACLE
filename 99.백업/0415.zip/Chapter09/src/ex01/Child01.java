package ex01;

public class Child01 extends Parent01{
						// 상속은 자식클래스에 extends 부모 클래스 이름
	// 멤버가 없음
	public Child01() {
		super("홍판서"); //  자동 생성되어 자동으로 부모 생성자를 호출
		
	}
	@Override   // 어노테이션 : 메서드의 부가기능, 첨삭기능
	void method() { //메서드 오버라이드
		System.out.println("나는 자식입니다.");
}
}
