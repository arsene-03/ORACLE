package ex02;

public class ConvertibleCar extends Car{
	
	public void open() {
		System.out.println("차량의 지붕을 엽니다.");
	}

}
