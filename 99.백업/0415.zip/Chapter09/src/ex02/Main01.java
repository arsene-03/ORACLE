package ex02;

public class Main01 {

	public static void main(String[] args) {
		Car myCar = new ConvertibleCar();
						// 자식인스턴스 (forward , backward, open(나만가지고있는)
		
		myCar.forward();
		myCar.backward();
	//	myCar.open();  // Car라는 부모클래스엔 open이 없어서 에러가뜸
		
		Car yourCar = new SUVCar();
					// 자식인스턴스 (forward(오버라이딩) , backward)
		
		yourCar.forward();
		yourCar.backward();
		
		
		SUVCar hisCar = (SUVCar)yourCar;
		//강제로 형변환이 가능함 => 실제 데이터는 같기때문에 가능함
		
		hisCar.forward();
		hisCar.backward();
	}
	
}
